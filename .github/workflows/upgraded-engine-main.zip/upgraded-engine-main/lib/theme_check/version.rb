# frozen_string_literal: true
module ThemeCheck
  VERSION = "1.2.0"
end
